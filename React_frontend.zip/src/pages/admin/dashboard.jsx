import { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard() {

  const [data, setData] = useState(null);

  useEffect(() => {

    const fetchProtectedData = async () => {

      try {

        const token = localStorage.getItem("token");

        const res = await axios.get(
          "http://localhost:3000/auth/me",
          {
            headers: {
              Authorization: `Bearer ${token}`
            }
          }
        );

        setData(res.data);

      } catch (err) {

        console.log(err.response?.data);

        if (err.response?.status === 401) {

          localStorage.removeItem("token");

          alert("Session expired");

          window.location.href = "/login";
        }
      }
    };

    fetchProtectedData();

  }, []);

  const [name, setName] = useState("");
  const [price, setPrice] = useState('');
  const handlePostItem = async (e) => {
    e.preventDefault();

    try {
      const token = localStorage.getItem("token");

      const res = await axios.post(
        "http://localhost:3000/items",
        { name, price },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      console.log("Item posted:", res.data);

      // reset form
      setName("");
      setPrice("");

      if (window.ngAlert) {
        window.ngAlert.success("Item posted successfully!");
      } else {
        alert("Item posted successfully!");
      }
      fetchItems();

    } catch (err) {
      console.log(err);

      alert(
        err.response?.data?.message ||
        "Post item failed"
      );
    }
  };

  const [items, setItems] = useState([]);
  const fetchItems = async () => {

    try {

      const token = localStorage.getItem("token");

      const res = await axios.get(
        "http://localhost:3000/items",
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      setItems(res.data);

    } catch (err) {
      console.log("Fetch items error:", err);
    }
  };
  useEffect(() => {
    fetchItems();
  }, []);
  return (
  <>
    <div>

      <h2>Admin Dashboard</h2>

      {data && (
        <div>
          <p>User: {data.user.username}</p>
          <form onSubmit={handlePostItem}>
           <input
              value={name}
              placeholder="Name"
              onChange={(e) => setName(e.target.value)}
            />

            <input
              value={price}
              placeholder="Price"
              onChange={(e) => setPrice(e.target.value)}
            />
            
            <button type="submit">
              Post Item
            </button>

          </form>
        </div>
        // item
      )}

    </div>
    <div>
      <h2>There is item here</h2>
      <ul>
        {items.map((item) => (
          <li key={item.id}>
            <strong>Name</strong>: {item.name} <strong>Price</strong>: {item.price}
          </li>
        ))}
      </ul>
    </div>
  </>
  );
}