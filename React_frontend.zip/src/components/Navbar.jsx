import { Link } from "react-router-dom";

export default function Navbar() {

  const token = localStorage.getItem("token");

  const logout = () => {

    localStorage.removeItem("token");

    window.location.href = "/login";
  };

  return (

    <nav>

      <Link to="/">
        Home
      </Link>

      {!token ? (
        <>
          <Link to="/login">
            Login
          </Link>

          <Link to="/register">
            Register
          </Link>
        </>
      ) : (
        <>
          <Link to="/admin">
            Dashboard
          </Link>

          <button onClick={logout}>
            Logout
          </button>
        </>
      )}

    </nav>
  );
}